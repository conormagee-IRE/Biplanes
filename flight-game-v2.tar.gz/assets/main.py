import asyncio
import math
import random
import pygame

# ---------- Config ----------
WIDTH, HEIGHT = 1280, 720
GROUND_HEIGHT = 80

FPS = 60
DT = .75 / FPS

# Physics constants
GRAVITY = 200.0
STALL_SPEED = 150.0
MAX_THRUST_ACCEL = 300.0
DRAG_COEFF = 0.002
AOA_DRAG_FACTOR = 0.5
THROTTLE_RAMP_RATE = 2
LANDING_MAX_SPEED = 250.0
LANDING_MAX_DESCENT = 200.0
GROUND_FRICTION = 180.0
BULLET_MUZZLE_SPEED = 500.0
BULLET_LIFETIME = 3.0
MAX_ACTIVE_BULLETS = 3
CLOUD_COUNT = 7
CLOUD_MIN_SCALE = 1.7
CLOUD_MAX_SCALE = 3.0
CLOUD_MIN_SPEED = 10.0
CLOUD_MAX_SPEED = 24.0
LIGHTNING_MIN_INTERVAL = 1.8
LIGHTNING_MAX_INTERVAL = 4.5
LIGHTNING_FLASH_DURATION = 0.22

# Plane drawing
PLANE_LENGTH = 32
PLANE_WIDTH = 16

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2D Flight Simulator - Dogfight Mode")
clock = pygame.time.Clock()
font = pygame.font.SysFont("consolas", 20)


def build_biplane_sprite(body_color, wing_color):
    sprite = pygame.Surface((52, 28), pygame.SRCALPHA)

    pygame.draw.ellipse(sprite, body_color, (10, 10, 24, 8))
    pygame.draw.polygon(sprite, body_color, [(31, 10), (46, 14), (31, 18)])
    pygame.draw.polygon(sprite, body_color, [(8, 14), (2, 10), (2, 18)])
    pygame.draw.rect(sprite, wing_color, pygame.Rect(13, 5, 21, 4), border_radius=2)
    pygame.draw.rect(sprite, wing_color, pygame.Rect(13, 19, 21, 4), border_radius=2)
    pygame.draw.rect(sprite, (70, 60, 45), pygame.Rect(18, 9, 2, 10), border_radius=1)
    pygame.draw.rect(sprite, (70, 60, 45), pygame.Rect(27, 9, 2, 10), border_radius=1)
    pygame.draw.polygon(sprite, (160, 120, 60), [(4, 11), (1, 14), (4, 17)])
    pygame.draw.circle(sprite, (230, 230, 240), (20, 14), 3)
    pygame.draw.circle(sprite, (40, 40, 40), (20, 14), 1)
    return sprite


def build_cloud_sprite(scale, edge_color=(252, 252, 255, 92), puff_color=(248, 248, 252, 255), shade_color=(222, 228, 236, 120)):
    width = int(90 * scale)
    height = int(42 * scale)
    sprite = pygame.Surface((width, height), pygame.SRCALPHA)

    puffs = [
        (int(width * 0.22), int(height * 0.58), int(height * 0.28)),
        (int(width * 0.42), int(height * 0.36), int(height * 0.36)),
        (int(width * 0.62), int(height * 0.48), int(height * 0.32)),
        (int(width * 0.78), int(height * 0.62), int(height * 0.24)),
    ]

    for x, y, radius in puffs:
        pygame.draw.circle(sprite, edge_color, (x, y), int(radius * 1.28))

    pygame.draw.ellipse(
        sprite,
        edge_color,
        pygame.Rect(int(width * 0.06), int(height * 0.40), int(width * 0.82), int(height * 0.46)),
    )

    for x, y, radius in puffs:
        pygame.draw.circle(sprite, puff_color, (x, y), radius)

    pygame.draw.ellipse(
        sprite,
        puff_color,
        pygame.Rect(int(width * 0.12), int(height * 0.46), int(width * 0.72), int(height * 0.36)),
    )
    pygame.draw.ellipse(
        sprite,
        shade_color,
        pygame.Rect(int(width * 0.18), int(height * 0.58), int(width * 0.58), int(height * 0.18)),
    )
    return sprite


def create_cloud(x=None, force_visible=False):
    scale = random.uniform(CLOUD_MIN_SCALE, CLOUD_MAX_SCALE)
    sprite = build_cloud_sprite(scale)
    y_limit = HEIGHT // 2 - sprite.get_height()
    if x is None:
        if force_visible:
            min_x = -sprite.get_width() * 0.2
            max_x = WIDTH - sprite.get_width() * 0.8
            x = random.uniform(min_x, max(min_x + 1, max_x))
        else:
            x = random.uniform(-WIDTH * 0.1, WIDTH)
    return {
        "x": x,
        "y": random.uniform(20, max(21, y_limit)),
        "speed": random.uniform(CLOUD_MIN_SPEED, CLOUD_MAX_SPEED),
        "sprite": sprite,
    }


def update_clouds(clouds, dt):
    right_edge = WIDTH + 80
    for cloud in clouds:
        cloud["x"] += cloud["speed"] * dt
        if cloud["x"] > right_edge:
            reset_cloud = create_cloud(-cloud["sprite"].get_width() - random.uniform(40, 220))
            cloud.update(reset_cloud)


def draw_clouds(surface, clouds):
    for cloud in clouds:
        surface.blit(cloud["sprite"], (int(cloud["x"]), int(cloud["y"])))


def create_storm_cloud(force_visible=False):
    sprite = build_cloud_sprite(
        random.uniform(2.0, 3.2),
        edge_color=(110, 116, 134, 90),
        puff_color=(84, 90, 110, 255),
        shade_color=(46, 52, 66, 160),
    )
    y_limit = HEIGHT // 2 - sprite.get_height()
    if force_visible:
        min_x = -sprite.get_width() * 0.1
        max_x = WIDTH - sprite.get_width() * 0.9
        x = random.uniform(min_x, max(min_x + 1, max_x))
    else:
        x = -sprite.get_width() - random.uniform(60, 200)

    return {
        "x": x,
        "y": random.uniform(25, max(26, y_limit)),
        "speed": random.uniform(CLOUD_MIN_SPEED * 0.7, CLOUD_MAX_SPEED * 0.85),
        "sprite": sprite,
        "lightning_timer": random.uniform(LIGHTNING_MIN_INTERVAL, LIGHTNING_MAX_INTERVAL),
        "lightning_duration": 0.0,
        "lightning_points": [],
    }


def build_lightning_points(storm_cloud):
    sprite = storm_cloud["sprite"]
    start_x = storm_cloud["x"] + sprite.get_width() * random.uniform(0.35, 0.65)
    start_y = storm_cloud["y"] + sprite.get_height()
    segment_count = 5
    segment_length = sprite.get_height() / segment_count
    points = [(start_x, start_y)]
    current_x = start_x
    current_y = start_y

    for _ in range(segment_count):
        current_x += random.uniform(-10, 10)
        current_y += segment_length
        points.append((current_x, current_y))

    return points


def update_storm_cloud(storm_cloud, dt):
    storm_cloud["x"] += storm_cloud["speed"] * dt
    if storm_cloud["x"] > WIDTH + 120:
        reset_cloud = create_storm_cloud(force_visible=False)
        storm_cloud.update(reset_cloud)
        return

    if storm_cloud["lightning_duration"] > 0.0:
        storm_cloud["lightning_duration"] = max(0.0, storm_cloud["lightning_duration"] - dt)
        if storm_cloud["lightning_duration"] == 0.0:
            storm_cloud["lightning_points"] = []
    else:
        storm_cloud["lightning_timer"] -= dt
        if storm_cloud["lightning_timer"] <= 0.0:
            storm_cloud["lightning_points"] = build_lightning_points(storm_cloud)
            storm_cloud["lightning_duration"] = LIGHTNING_FLASH_DURATION
            storm_cloud["lightning_timer"] = random.uniform(LIGHTNING_MIN_INTERVAL, LIGHTNING_MAX_INTERVAL)


def draw_storm_cloud(surface, storm_cloud):
    surface.blit(storm_cloud["sprite"], (int(storm_cloud["x"]), int(storm_cloud["y"])))

    if not storm_cloud["lightning_points"]:
        return

    glow_points = [(int(x), int(y)) for x, y in storm_cloud["lightning_points"]]
    pygame.draw.lines(surface, (255, 255, 210), False, glow_points, 8)
    pygame.draw.lines(surface, (255, 248, 170), False, glow_points, 4)


def point_to_segment_distance(px, py, ax, ay, bx, by):
    abx = bx - ax
    aby = by - ay
    ab_len_sq = abx * abx + aby * aby
    if ab_len_sq == 0:
        return math.hypot(px - ax, py - ay)

    t = ((px - ax) * abx + (py - ay) * aby) / ab_len_sq
    t = max(0.0, min(1.0, t))
    closest_x = ax + t * abx
    closest_y = ay + t * aby
    return math.hypot(px - closest_x, py - closest_y)


def lightning_hits_plane(storm_cloud, plane):
    points = storm_cloud["lightning_points"]
    if len(points) < 2:
        return False

    plane_radius = PLANE_LENGTH * 0.45
    for index in range(len(points) - 1):
        ax, ay = points[index]
        bx, by = points[index + 1]
        if point_to_segment_distance(plane.x, plane.y, ax, ay, bx, by) <= plane_radius + 2:
            return True
    return False


# ---------------------------------------------------------
# Plane Class
# ---------------------------------------------------------
class Plane:
    def __init__(self, x, y, angle, sprite):
        self.start_x = x
        self.start_y = y
        self.start_angle = angle
        self.base_sprite = sprite

        self.x = x
        self.y = y
        self.vx = 0.0
        self.vy = 0.0
        self.angle = angle
        self.thrust_level = 0.0

        self.bullets = []  # [(x, y, vx, vy, age), ...]

    def reset(self):
        self.x = self.start_x
        self.y = self.start_y
        self.vx = 0.0
        self.vy = 0.0
        self.angle = self.start_angle
        self.thrust_level = 0.0
        self.bullets = []

    def crash(self):
        self.reset()

    @property
    def speed(self):
        return math.hypot(self.vx, self.vy)

    @property
    def forward_vector(self):
        return math.cos(self.angle), math.sin(self.angle)

    @property
    def velocity_direction(self):
        if self.speed < 1e-5:
            return 1.0, 0.0
        return self.vx / self.speed, self.vy / self.speed

    @property
    def forward_speed(self):
        fx, fy = self.forward_vector
        return self.vx * fx + self.vy * fy

    @property
    def angle_of_attack(self):
        fx_s, fy_s = self.forward_vector
        vx_s, vy_s = self.velocity_direction

        fx, fy = fx_s, -fy_s
        vx, vy = vx_s, -vy_s

        dot = vx * fx + vy * fy
        cross = vx * fy - vy * fx

        aoa = math.atan2(cross, dot)

        if self.vx < 0:
            aoa = -aoa

        return aoa

    # ---------------------------------------------------------
    # Bullet firing
    # ---------------------------------------------------------
    def fire(self):
        if len(self.bullets) >= MAX_ACTIVE_BULLETS:
            return

        fx, fy = self.forward_vector
        bullet_speed = BULLET_MUZZLE_SPEED + max(0.0, self.forward_speed)

        self.bullets.append([
            self.x,
            self.y,
            fx * bullet_speed,
            fy * bullet_speed,
            0.0  # age
        ])

    def update_bullets(self, dt):
        active_bullets = []

        for bx, by, bvx, bvy, age in self.bullets:
            bx += bvx * dt
            by += bvy * dt
            age += dt

            if age < BULLET_LIFETIME:
                active_bullets.append([bx, by, bvx, bvy, age])

        self.bullets = active_bullets

    # ---------------------------------------------------------
    # Physics update
    # ---------------------------------------------------------
    def update(self, dt):
        ax, ay = 0.0, 0.0
        crashed = False
        ground_y = HEIGHT - GROUND_HEIGHT
        was_airborne = self.y < ground_y - 1

        ay += GRAVITY

        fx, fy = self.forward_vector
        thrust_accel = self.thrust_level * MAX_THRUST_ACCEL

        altitude_factor = self.y / (HEIGHT - GROUND_HEIGHT)
        altitude_factor = max(0.1, altitude_factor)
        thrust_accel *= (altitude_factor * 1.5)

        ax += fx * thrust_accel
        ay += fy * thrust_accel

        vx_m, vy_m = self.vx, -self.vy
        climb_angle = math.atan2(vy_m, vx_m)
        forward_gravity = GRAVITY * math.sin(climb_angle)

        ax += -fx * forward_gravity
        ay += -fy * forward_gravity

        if self.speed > 1e-3:
            drag_dir_x = -self.vx / self.speed
            drag_dir_y = -self.vy / self.speed
            aoa = abs(self.angle_of_attack)
            drag_mag = DRAG_COEFF * (self.speed ** 2) * (1.0 + AOA_DRAG_FACTOR * aoa)
            ax += drag_dir_x * drag_mag
            ay += drag_dir_y * drag_mag

        if self.forward_speed > STALL_SPEED:
            aoa = self.angle_of_attack
            lift_factor = 1.0 + 0.8 * aoa
            lift_factor = max(0.2, min(1.8, lift_factor))

            altitude_ratio = self.y / (HEIGHT - GROUND_HEIGHT)
            altitude_lift_factor = 1.0 - 0.6 * altitude_ratio
            altitude_lift_factor = max(0.2, altitude_lift_factor)

            ay -= GRAVITY * lift_factor * altitude_lift_factor

        self.vx += ax * dt
        self.vy += ay * dt

        next_x = self.x + self.vx * dt
        next_y = self.y + self.vy * dt

        self.x = next_x
        if self.x < 0:
            self.x += WIDTH
        elif self.x > WIDTH:
            self.x -= WIDTH

        if next_y < 0:
            self.y = 0
            self.vy = 0
        elif next_y > ground_y:
            ground_speed = abs(self.vx)
            descent_rate = max(0.0, self.vy)
            if was_airborne and (ground_speed > LANDING_MAX_SPEED or descent_rate > LANDING_MAX_DESCENT):
                self.crash()
                crashed = True
            else:
                self.y = ground_y
                self.vy = 0.0
                if self.vx > 0:
                    self.vx = max(0.0, self.vx - GROUND_FRICTION * dt)
                elif self.vx < 0:
                    self.vx = min(0.0, self.vx + GROUND_FRICTION * dt)
        else:
            self.y = next_y

        if self.y > ground_y:
            self.y = ground_y
            self.vy = 0.0

        self.update_bullets(dt)
        return crashed

    # ---------------------------------------------------------
    # Drawing
    # ---------------------------------------------------------
    def draw(self, surface):
        rotated_sprite = pygame.transform.rotate(self.base_sprite, -math.degrees(self.angle))
        sprite_rect = rotated_sprite.get_rect(center=(int(self.x), int(self.y)))
        surface.blit(rotated_sprite, sprite_rect)

        for bx, by, *_ in self.bullets:
            pygame.draw.circle(surface, (255, 255, 0), (int(bx), int(by)), 4)


# ---------------------------------------------------------
# HUD
# ---------------------------------------------------------
def draw_hud_left(surface, plane):
    texts = [
        f"Speed: {plane.forward_speed:6.1f}",
        f"Thrust: {plane.thrust_level*100:5.1f}%",
        f"AoA: {math.degrees(plane.angle_of_attack):6.1f}"
    ]
    for i, t in enumerate(texts):
        img = font.render(t, True, (255, 255, 255))
        surface.blit(img, (10, 10 + i * 22))


def draw_hud_right(surface, plane):
    texts = [
        f"Speed: {plane.forward_speed:6.1f}",
        f"Thrust: {plane.thrust_level*100:5.1f}%",
        f"AoA: {math.degrees(plane.angle_of_attack):6.1f}"
    ]
    for i, t in enumerate(texts):
        img = font.render(t, True, (255, 255, 255))
        surface.blit(img, (WIDTH - 220, 10 + i * 22))


# ---------------------------------------------------------
# Collision helpers
# ---------------------------------------------------------
def plane_on_ground(plane):
    return plane.y >= HEIGHT - GROUND_HEIGHT - 1


def get_hit_bullet_index(bullets, plane):
    for index, bullet in enumerate(bullets):
        bx, by, *_ = bullet
        if math.hypot(bx - plane.x, by - plane.y) < PLANE_LENGTH * 0.45:
            return index
    return None


def planes_collide(p1, p2):
    return math.hypot(p1.x - p2.x, p1.y - p2.y) < PLANE_LENGTH * 0.9


# ---------------------------------------------------------
# Main
# ---------------------------------------------------------
async def main():
    # Plane 1 (WASD) — left side
    spawn_margin = 180
    plane1_sprite = build_biplane_sprite((210, 70, 55), (245, 215, 120))
    plane2_sprite = build_biplane_sprite((60, 90, 190), (225, 235, 245))
    plane1 = Plane(spawn_margin, HEIGHT - GROUND_HEIGHT, math.radians(-30), plane1_sprite)

    # Plane 2 (Arrow Keys) — right side
    plane2 = Plane(WIDTH - spawn_margin, HEIGHT - GROUND_HEIGHT, math.radians(-150), plane2_sprite)

    score1 = 0
    score2 = 0
    plane1_fire_was_down = False
    plane2_fire_was_down = False
    clouds = [create_cloud(force_visible=True) for _ in range(CLOUD_COUNT)]
    storm_cloud = create_storm_cloud(force_visible=True)

    running = True
    while running:
        dt = DT
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()

        # Plane 1 controls (WASD + F to fire)
        if keys[pygame.K_w]:
            plane1.angle -= 2.5 * dt
        if keys[pygame.K_s]:
            plane1.angle += 2.5 * dt
        if keys[pygame.K_d]:
            plane1.thrust_level = min(1.0, plane1.thrust_level + THROTTLE_RAMP_RATE * dt)
        if keys[pygame.K_a]:
            plane1.thrust_level = max(0.0, plane1.thrust_level - THROTTLE_RAMP_RATE * dt)
        if keys[pygame.K_f] and not plane1_fire_was_down:
            plane1.fire()

        # Plane 2 controls (Arrows + RCTRL to fire)
        if keys[pygame.K_UP]:
            plane2.angle -= 2.5 * dt
        if keys[pygame.K_DOWN]:
            plane2.angle += 2.5 * dt
        if keys[pygame.K_RIGHT]:
            plane2.thrust_level = min(1.0, plane2.thrust_level + THROTTLE_RAMP_RATE * dt)
        if keys[pygame.K_LEFT]:
            plane2.thrust_level = max(0.0, plane2.thrust_level - THROTTLE_RAMP_RATE * dt)
        if keys[pygame.K_RCTRL] and not plane2_fire_was_down:
            plane2.fire()

        plane1_fire_was_down = keys[pygame.K_f]
        plane2_fire_was_down = keys[pygame.K_RCTRL]

        update_clouds(clouds, dt)
        update_storm_cloud(storm_cloud, dt)

        plane1_crashed = plane1.update(dt)
        plane2_crashed = plane2.update(dt)

        if plane1_crashed:
            score2 += 1
        if plane2_crashed:
            score1 += 1

        if lightning_hits_plane(storm_cloud, plane1):
            score2 += 1
            plane1.crash()

        if lightning_hits_plane(storm_cloud, plane2):
            score1 += 1
            plane2.crash()

        # --- Bullet hits (ignore grounded planes) ---
        hit_index = None
        if not plane_on_ground(plane2):
            hit_index = get_hit_bullet_index(plane1.bullets, plane2)
        if hit_index is not None:
            score1 += 1
            plane2.reset()
            del plane1.bullets[hit_index]

        hit_index = None
        if not plane_on_ground(plane1):
            hit_index = get_hit_bullet_index(plane2.bullets, plane1)
        if hit_index is not None:
            score2 += 1
            plane1.reset()
            del plane2.bullets[hit_index]

        # --- Plane-plane collisions (ignore grounded planes) ---
        if planes_collide(plane1, plane2):
            if not plane_on_ground(plane1) and not plane_on_ground(plane2):
                if plane1.forward_speed < plane2.forward_speed:
                    plane1.reset()
                else:
                    plane2.reset()

        # --- Drawing ---
        screen.fill((80, 150, 255))

        pygame.draw.rect(screen, (40, 120, 40),
                         pygame.Rect(0, HEIGHT - GROUND_HEIGHT, WIDTH, GROUND_HEIGHT))

        plane1.draw(screen)
        plane2.draw(screen)
        draw_clouds(screen, clouds)
        draw_storm_cloud(screen, storm_cloud)

        draw_hud_left(screen, plane1)
        draw_hud_right(screen, plane2)

        score_text = font.render(f"{score1}   SCORE   {score2}", True, (255, 255, 255))
        screen.blit(score_text, (WIDTH//2 - 80, 10))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
